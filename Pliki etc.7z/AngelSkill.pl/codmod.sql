-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 03 Wrz 2015, 22:10
-- Wersja serwera: 5.1.73
-- Wersja PHP: 5.3.3-7+squeeze23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `db`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla tabeli `codmod`
--

CREATE TABLE IF NOT EXISTS `codmod` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `steamid` varchar(48) COLLATE utf8_polish_ci NOT NULL,
  `class` varchar(48) COLLATE utf8_polish_ci NOT NULL,
  `lvl` int(11) DEFAULT '1',
  `exp` int(14) DEFAULT NULL,
  `sInt` int(9) DEFAULT NULL,
  `sCon` int(9) DEFAULT NULL,
  `sStr` int(9) DEFAULT NULL,
  `sDex` int(9) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class_sid` (`class`,`steamid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=258147 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
